VERSION = (1, 3, 4)


def get_version():
    return '.'.join(map(str, VERSION))
